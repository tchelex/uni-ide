@echo off
REM ============================================================
REM  build_exe.bat - сборка офлайн-бандла UNI IDE (Windows)
REM  Запускать ПОСЛЕ prepare_bundle.py (нужна папка arduino-data)
REM ============================================================
chcp 65001 >nul
setlocal

echo [1/4] Проверка папки arduino-data...
if not exist "arduino-data" (
  echo ОШИБКА: папка arduino-data не найдена.
  echo Сначала выполните:  python prepare_bundle.py
  pause
  exit /b 1
)

echo [2/4] Установка инструментов сборки...
python -m pip install --upgrade pyinstaller flask pyserial

echo [3/4] Сборка UNI-IDE.exe (PyInstaller)...
pyinstaller --noconfirm --noconsole --onedir --name UNI-IDE server.py
if errorlevel 1 ( echo Сборка не удалась. & pause & exit /b 1 )

echo [4/4] Копирование тулчейна и ресурсов рядом с exe...
set OUT=dist\UNI-IDE
copy /Y index.html "%OUT%\" >nul
copy /Y arduino-cli.exe "%OUT%\" >nul
xcopy /E /I /Y arduino-data "%OUT%\arduino-data" >nul
if exist arduino-user xcopy /E /I /Y arduino-user "%OUT%\arduino-user" >nul
if exist drivers xcopy /E /I /Y drivers "%OUT%\drivers" >nul
if exist student-README.txt copy /Y student-README.txt "%OUT%\" >nul

echo.
echo ================== ГОТОВО ==================
echo Бандл собран в:  %OUT%
echo Заархивируйте ВСЮ папку %OUT% в zip и раздайте ученикам.
echo Ученик распаковывает папку и запускает UNI-IDE.exe
echo ============================================
pause
endlocal
