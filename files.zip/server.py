#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNI IDE — простая локальная IDE для ESP32 Dev Module.

Работает в двух режимах:
  1) как обычный python-скрипт (для разработки) — использует системный arduino-cli;
  2) как собранный .exe (PyInstaller) с ПЕРЕНОСИМЫМ тулчейном — всё офлайн,
     рядом с exe лежит arduino-cli.exe и папка arduino-data с ядром ESP32.

Загрузка зашита ТОЛЬКО на плату ESP32 Dev Module (FQBN esp32:esp32:esp32).
"""

import os
import sys
import json
import shutil
import threading
import webbrowser
import subprocess

from flask import Flask, request, jsonify, send_from_directory

try:
    import serial
    from serial.tools import list_ports
    HAS_PYSERIAL = True
except Exception:
    HAS_PYSERIAL = False

# --------------------------------------------------------------------------- #
# Расположение файлов: работает и для скрипта, и для собранного .exe
# --------------------------------------------------------------------------- #
def base_dir():
    if getattr(sys, "frozen", False):          # запущено как .exe
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

BASE = base_dir()
IS_FROZEN = getattr(sys, "frozen", False)

# Переносимый тулчейн (присутствует только в подготовленном бандле)
PORTABLE_DATA = os.path.join(BASE, "arduino-data")
PORTABLE_USER = os.path.join(BASE, "arduino-user")
PORTABLE_DL   = os.path.join(BASE, "arduino-downloads")
IS_PORTABLE   = os.path.isdir(PORTABLE_DATA)

# Плата зафиксирована: ESP32 Dev Module
FQBN = "esp32:esp32:esp32"


def resolve_cli():
    """Бандл: arduino-cli.exe рядом. Иначе — системный из PATH."""
    for name in ("arduino-cli.exe", "arduino-cli"):
        p = os.path.join(BASE, name)
        if os.path.exists(p):
            return p
    return os.environ.get("ARDUINO_CLI", "arduino-cli")

ARDUINO_CLI = resolve_cli()


def cli_env():
    """Окружение для arduino-cli. В бандле указываем переносимые каталоги."""
    env = dict(os.environ)
    if IS_PORTABLE:
        env["ARDUINO_DIRECTORIES_DATA"] = PORTABLE_DATA
        env["ARDUINO_DIRECTORIES_USER"] = PORTABLE_USER
        env["ARDUINO_DIRECTORIES_DOWNLOADS"] = PORTABLE_DL
    return env


def writable_workspace():
    """Папка для скетча. Рядом с exe, если можно писать; иначе — в LOCALAPPDATA."""
    try:
        t = os.path.join(BASE, ".w_test")
        with open(t, "w") as f:
            f.write("x")
        os.remove(t)
        return BASE
    except Exception:
        d = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "UNI-IDE")
        os.makedirs(d, exist_ok=True)
        return d

WORKSPACE   = writable_workspace()
SKETCH_NAME = "UNI_Sketch"
SKETCH_DIR  = os.path.join(WORKSPACE, SKETCH_NAME)
SKETCH_FILE = os.path.join(SKETCH_DIR, SKETCH_NAME + ".ino")

DEFAULT_CODE = """// UNI IDE — ESP32 Dev Module
// Пример: мигание встроенным светодиодом

#define LED_PIN 2  // встроенный LED на большинстве ESP32 Dev Module

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  Serial.println("UNIBASE on ESP32 ready");
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("blink ON");
  delay(500);
  digitalWrite(LED_PIN, LOW);
  delay(500);
}
"""

app = Flask(__name__, static_folder=None)

# --------------------------------------------------------------------------- #
# Хелперы
# --------------------------------------------------------------------------- #
def ensure_sketch():
    os.makedirs(SKETCH_DIR, exist_ok=True)
    if not os.path.exists(SKETCH_FILE):
        with open(SKETCH_FILE, "w", encoding="utf-8") as f:
            f.write(DEFAULT_CODE)


def run_cli(args, timeout=900):
    """Запуск arduino-cli. Возвращает (ok, stdout, stderr)."""
    cmd = [ARDUINO_CLI] + args
    try:
        p = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            env=cli_env(),
        )
        return p.returncode == 0, p.stdout or "", p.stderr or ""
    except FileNotFoundError:
        return False, "", (
            "arduino-cli не найден. В бандле он должен лежать рядом с UNI-IDE.exe; "
            "в режиме разработки — быть в PATH. См. README."
        )
    except subprocess.TimeoutExpired:
        return False, "", "Превышено время ожидания операции."
    except Exception as e:  # noqa: BLE001
        return False, "", f"Ошибка запуска arduino-cli: {e}"


def save_code(code):
    ensure_sketch()
    with open(SKETCH_FILE, "w", encoding="utf-8") as f:
        f.write(code)


# --------------------------------------------------------------------------- #
# Serial-монитор (pyserial)
# --------------------------------------------------------------------------- #
class Monitor:
    def __init__(self):
        self.ser = None
        self.port = None
        self.baud = None
        self.buffer = []
        self.lock = threading.Lock()
        self.running = False
        self.thread = None

    def start(self, port, baud):
        self.stop()
        if not HAS_PYSERIAL:
            raise RuntimeError("pyserial не установлен (pip install pyserial)")
        self.ser = serial.Serial(port, int(baud), timeout=0.2)
        self.port = port
        self.baud = baud
        self.running = True
        self.thread = threading.Thread(target=self._reader, daemon=True)
        self.thread.start()

    def _reader(self):
        while self.running and self.ser:
            try:
                line = self.ser.readline()
                if line:
                    text = line.decode("utf-8", errors="replace")
                    with self.lock:
                        self.buffer.append(text)
                        if len(self.buffer) > 2000:
                            self.buffer = self.buffer[-1000:]
            except Exception:
                break

    def read(self):
        with self.lock:
            out = "".join(self.buffer)
            self.buffer = []
        return out

    def send(self, data):
        if self.ser and self.running:
            self.ser.write((data + "\n").encode("utf-8"))

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=1)
            self.thread = None
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
            self.ser = None

    def is_on(self, port=None):
        if not self.running:
            return False
        if port is None:
            return True
        return self.port == port


monitor = Monitor()

# --------------------------------------------------------------------------- #
# Маршруты — страница
# --------------------------------------------------------------------------- #
@app.route("/")
def index():
    return send_from_directory(BASE, "index.html")


# --------------------------------------------------------------------------- #
# Маршруты — код
# --------------------------------------------------------------------------- #
@app.route("/api/code", methods=["GET"])
def get_code():
    ensure_sketch()
    with open(SKETCH_FILE, "r", encoding="utf-8") as f:
        return jsonify({"code": f.read(), "fqbn": FQBN, "sketch": SKETCH_NAME})


@app.route("/api/save", methods=["POST"])
def save():
    save_code(request.json.get("code", ""))
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
# Маршруты — порты
# --------------------------------------------------------------------------- #
@app.route("/api/ports", methods=["GET"])
def ports():
    found = []
    ok, out, _ = run_cli(["board", "list", "--format", "json"])
    if ok and out.strip():
        try:
            data = json.loads(out)
            rows = data if isinstance(data, list) else data.get("detected_ports", [])
            for row in rows:
                port_info = row.get("port", row)
                addr = port_info.get("address")
                if addr:
                    found.append(addr)
        except Exception:
            pass
    if HAS_PYSERIAL:
        for p in list_ports.comports():
            if p.device not in found:
                found.append(p.device)
    return jsonify({"ports": found})


# --------------------------------------------------------------------------- #
# Маршруты — компиляция / загрузка
# --------------------------------------------------------------------------- #
@app.route("/api/compile", methods=["POST"])
def compile_sketch():
    save_code(request.json.get("code", ""))
    ok, out, err = run_cli(["compile", "--fqbn", FQBN, SKETCH_DIR])
    return jsonify({"ok": ok, "log": (out + err).strip()})


@app.route("/api/upload", methods=["POST"])
def upload_sketch():
    body = request.json or {}
    port = body.get("port")
    if not port:
        return jsonify({"ok": False, "log": "Не выбран COM-порт."})

    save_code(body.get("code", ""))

    monitor_was_on = monitor.is_on(port)
    monitor_baud = monitor.baud
    if monitor_was_on:
        monitor.stop()

    ok, out, err = run_cli(
        ["compile", "--upload", "-p", port, "--fqbn", FQBN, SKETCH_DIR]
    )

    if monitor_was_on:
        try:
            monitor.start(port, monitor_baud or 115200)
        except Exception:
            pass

    return jsonify({"ok": ok, "log": (out + err).strip()})


# --------------------------------------------------------------------------- #
# Маршруты — библиотеки
# --------------------------------------------------------------------------- #
@app.route("/api/libs", methods=["GET"])
def libs_list():
    ok, out, err = run_cli(["lib", "list", "--format", "json"])
    items = []
    if ok and out.strip():
        try:
            data = json.loads(out)
            rows = data if isinstance(data, list) else data.get("installed_libraries", [])
            for row in rows:
                lib = row.get("library", row)
                items.append({"name": lib.get("name"), "version": lib.get("version")})
        except Exception:
            pass
    return jsonify({"ok": ok, "libs": items, "log": err.strip()})


@app.route("/api/lib/search", methods=["POST"])
def libs_search():
    q = (request.json or {}).get("q", "").strip()
    if not q:
        return jsonify({"ok": False, "results": [], "log": "Пустой запрос."})
    ok, out, err = run_cli(["lib", "search", q, "--format", "json"])
    results = []
    if ok and out.strip():
        try:
            data = json.loads(out)
            rows = data.get("libraries", data if isinstance(data, list) else [])
            for row in rows[:30]:
                latest = row.get("latest", {})
                results.append({
                    "name": row.get("name"),
                    "version": latest.get("version", ""),
                    "sentence": latest.get("sentence", ""),
                })
        except Exception:
            pass
    return jsonify({"ok": ok, "results": results, "log": err.strip()})


@app.route("/api/lib/install", methods=["POST"])
def libs_install():
    name = (request.json or {}).get("name", "").strip()
    if not name:
        return jsonify({"ok": False, "log": "Не указано имя библиотеки."})
    ok, out, err = run_cli(["lib", "install", name])
    return jsonify({"ok": ok, "log": (out + err).strip()})


# --------------------------------------------------------------------------- #
# Маршруты — serial-монитор
# --------------------------------------------------------------------------- #
@app.route("/api/monitor/start", methods=["POST"])
def mon_start():
    body = request.json or {}
    port = body.get("port")
    baud = body.get("baud", 115200)
    if not port:
        return jsonify({"ok": False, "log": "Не выбран порт."})
    try:
        monitor.start(port, baud)
        return jsonify({"ok": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"ok": False, "log": str(e)})


@app.route("/api/monitor/stop", methods=["POST"])
def mon_stop():
    monitor.stop()
    return jsonify({"ok": True})


@app.route("/api/monitor/read", methods=["GET"])
def mon_read():
    return jsonify({"data": monitor.read(), "on": monitor.is_on()})


@app.route("/api/monitor/send", methods=["POST"])
def mon_send():
    monitor.send((request.json or {}).get("data", ""))
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
# Проверка окружения
# --------------------------------------------------------------------------- #
@app.route("/api/env", methods=["GET"])
def env():
    cli_ok = shutil.which(ARDUINO_CLI) is not None or os.path.exists(ARDUINO_CLI)
    core_ok = False
    ver = ""
    if cli_ok:
        ok, out, _ = run_cli(["version"])
        ver = out.strip() if ok else ""
        ok2, out2, _ = run_cli(["core", "list", "--format", "json"])
        if ok2 and "esp32:esp32" in (out2 or ""):
            core_ok = True
    return jsonify({
        "arduino_cli": cli_ok,
        "esp32_core": core_ok,
        "pyserial": HAS_PYSERIAL,
        "portable": IS_PORTABLE,
        "version": ver,
        "fqbn": FQBN,
    })


def open_browser():
    try:
        webbrowser.open("http://127.0.0.1:5000")
    except Exception:
        pass


if __name__ == "__main__":
    # В собранном .exe без консоли пишем ошибки в лог-файл
    if IS_FROZEN:
        try:
            logf = open(os.path.join(WORKSPACE, "uni-ide-log.txt"), "w", encoding="utf-8")
            sys.stdout = logf
            sys.stderr = logf
        except Exception:
            pass
    ensure_sketch()
    threading.Timer(1.2, open_browser).start()
    print("UNI IDE → http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
